# BGT SPAMBOT

<p align="center">
  <img src="https://te.legra.ph/file/62d8a588996d71a3cce98.jpg">
</p>


[![Codacy Badge](https://api.codacy.com/project/badge/Grade/f7c51539e67b483bb8d7749acca51d3a)](https://app.codacy.com/gh/sameerpanthi/deadly-spam-bot?utm_source=github.com&utm_medium=referral&utm_content=sameerpanthi/deadly-spam-bot&utm_campaign=Badge_Grade_Settings)
[![Size](https://img.shields.io/github/repo-size/sameerpanthi/deadly-spam-bot?style=flat-square&color=green)](https://github.com/sameerpanthi/deadly-spam-bot/)   
[![Python](https://img.shields.io/badge/Python-v3.9-blue)](https://www.python.org/)
[![Maintenance](https://img.shields.io/badge/Maintained%3F-yes-green.svg)](https://github.com/sameerpanthi/deadly-spam-bot/graphs/commit-activity)
[![Open Source Love svg2](https://badges.frapsoft.com/os/v2/open-source.svg?v=103)](https://github.com/sameerpanthi/deadly-spam-bot)   
[![Contributors](https://img.shields.io/github/contributors/sameerpanthi/deadly-spam-bot?style=flat-square&color=green)](https://github.com/sameerpanthi/deadly-spam-bot/graphs/contributors)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg?style=flat-square)](https://makeapullrequest.com)
[![License](https://img.shields.io/badge/License-AGPL-blue)](https://github.com/sameerpanthi/deadly-spam-bot/blob/main/LICENSE)



## 𝚂𝚄𝙿𝙿𝙾𝚁𝚃 
                          
<a href="https://t.me/bgt_chat"><img src="https://img.shields.io/badge/Join-SUPPORT%20GROUP-red.svg?logo=Telegram"></a>
<a href="https://t.me/bgt_chat"><img src="https://img.shields.io/badge/Join-SUPPORT%20CHANNEL-red.svg?logo=Telegram"></a>

-------------------------------------------------

#### With Heroku

<a href="https://www.heroku.com/deploy?template=https://github.com/BgtUserbot/Deploy">
  <img src="https://www.herokucdn.com/deploy/button.svg">
</a>


-------------------------------------------------

## credits 


[Bgt Chat](t.me/bgt_chat)
